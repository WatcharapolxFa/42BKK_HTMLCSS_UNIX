ls | wc -l | tr -d ' '
